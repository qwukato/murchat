'use strict';
// Мурчат — сервер без внешних зависимостей (нужен только Node.js 18+).
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const PUBLIC = path.join(__dirname, 'public');

// Разрешённые буквы: Т Ы Ф Ь (кириллица)
const ALLOWED = /^[ТЫФЬ]+$/;
const PHOTOS = ['c1', 'c2', 'c3', 'c4'];
const MAX_TEXT = 300;

// ---------- база (один JSON-файл) ----------
fs.mkdirSync(DATA_DIR, { recursive: true });
let db = { users: {}, sessions: {}, messages: [], reads: {}, nextId: 1 };
try {
  db = Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE, 'utf8')));
} catch (e) { /* первый запуск */ }

let saveTimer = null;
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    const tmp = DB_FILE + '.tmp';
    fs.writeFile(tmp, JSON.stringify(db), (err) => {
      if (!err) fs.rename(tmp, DB_FILE, () => {});
    });
  }, 300);
}

// ---------- помощники ----------
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
};

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (c) => { data += c; if (data.length > 10000) { reject(new Error('big')); req.destroy(); } });
    req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch (e) { reject(e); } });
    req.on('error', reject);
  });
}

function hashPass(pass, salt) {
  return crypto.scryptSync(pass, salt, 32).toString('hex');
}

function normName(s) {
  return String(s || '').trim().replace(/^@/, '').toLowerCase();
}

const NAME_RE = /^[a-z0-9_]{3,20}$/;

// простейшее ограничение частоты для входа/регистрации
const hits = new Map();
function tooMany(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 10 * 60 * 1000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > 30;
}

function authUser(req, url) {
  let token = (req.headers.authorization || '').replace(/^Bearer /, '');
  if (!token && url) token = url.searchParams.get('token') || '';
  const name = db.sessions[token];
  return name && db.users[name] ? name : null;
}

function publicUser(name) {
  const u = db.users[name];
  return { username: name, avatar: u ? u.avatar : null };
}

// ---------- реальное время (SSE) ----------
const clients = new Map(); // username -> Set(res)
function push(name, event) {
  const set = clients.get(name);
  if (!set) return;
  const line = `data: ${JSON.stringify(event)}\n\n`;
  for (const r of set) r.write(line);
}
setInterval(() => {
  for (const set of clients.values()) for (const r of set) r.write(': ping\n\n');
}, 25000);

// ---------- API ----------
async function api(req, res, url) {
  const p = url.pathname;
  const method = req.method;
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '';

  if (p === '/api/register' && method === 'POST') {
    if (tooMany(ip)) return send(res, 429, { error: 'Слишком много попыток, подожди немного' });
    const b = await readBody(req);
    const name = normName(b.username);
    const pass = String(b.password || '');
    if (!NAME_RE.test(name)) return send(res, 400, { error: 'Юзернейм: 3–20 символов, латиница, цифры и _' });
    if (pass.length < 4 || pass.length > 64) return send(res, 400, { error: 'Пароль: от 4 символов' });
    if (db.users[name]) return send(res, 409, { error: 'Такой юзернейм уже занят' });
    const salt = crypto.randomBytes(16).toString('hex');
    db.users[name] = { salt, hash: hashPass(pass, salt), avatar: null, created: Date.now() };
    const token = crypto.randomBytes(32).toString('hex');
    db.sessions[token] = name;
    save();
    return send(res, 200, { token, me: publicUser(name) });
  }

  if (p === '/api/login' && method === 'POST') {
    if (tooMany(ip)) return send(res, 429, { error: 'Слишком много попыток, подожди немного' });
    const b = await readBody(req);
    const name = normName(b.username);
    const u = db.users[name];
    if (!u || hashPass(String(b.password || ''), u.salt) !== u.hash) {
      return send(res, 401, { error: 'Неверный юзернейм или пароль' });
    }
    const token = crypto.randomBytes(32).toString('hex');
    db.sessions[token] = name;
    save();
    return send(res, 200, { token, me: publicUser(name) });
  }

  // дальше — только для вошедших
  const me = authUser(req, url);
  if (!me) return send(res, 401, { error: 'Нужно войти' });

  if (p === '/api/events' && method === 'GET') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache',
      Connection: 'keep-alive', 'X-Accel-Buffering': 'no',
    });
    res.write('retry: 3000\n\n');
    if (!clients.has(me)) clients.set(me, new Set());
    clients.get(me).add(res);
    req.on('close', () => { const s = clients.get(me); if (s) { s.delete(res); if (!s.size) clients.delete(me); } });
    return;
  }

  if (p === '/api/me' && method === 'GET') return send(res, 200, publicUser(me));

  if (p === '/api/me' && method === 'PUT') {
    const b = await readBody(req);
    if (b.avatar !== null && !PHOTOS.includes(b.avatar)) return send(res, 400, { error: 'Нет такой фотографии' });
    db.users[me].avatar = b.avatar;
    save();
    return send(res, 200, publicUser(me));
  }

  if (p === '/api/logout' && method === 'POST') {
    const token = (req.headers.authorization || '').replace(/^Bearer /, '');
    delete db.sessions[token];
    save();
    return send(res, 200, { ok: true });
  }

  if (p === '/api/users' && method === 'GET') {
    const q = normName(url.searchParams.get('q'));
    if (!q) return send(res, 200, []);
    const found = Object.keys(db.users)
      .filter((n) => n !== me && n.includes(q))
      .sort((a, b) => (b.startsWith(q) - a.startsWith(q)) || a.localeCompare(b))
      .slice(0, 20)
      .map(publicUser);
    return send(res, 200, found);
  }

  if (p === '/api/chats' && method === 'GET') {
    const map = new Map();
    for (const m of db.messages) {
      if (m.from !== me && m.to !== me) continue;
      const other = m.from === me ? m.to : m.from;
      const c = map.get(other) || { with: other, unread: 0, last: null };
      c.last = m;
      if (m.to === me && m.id > ((db.reads[me] || {})[other] || 0)) c.unread++;
      map.set(other, c);
    }
    const list = [...map.values()].sort((a, b) => b.last.id - a.last.id)
      .map((c) => ({ ...c, user: publicUser(c.with) }));
    return send(res, 200, list);
  }

  let m = p.match(/^\/api\/messages\/([a-z0-9_]+)$/);
  if (m && method === 'GET') {
    const other = m[1];
    if (!db.users[other]) return send(res, 404, { error: 'Нет такого пользователя' });
    const msgs = db.messages.filter((x) => (x.from === me && x.to === other) || (x.from === other && x.to === me));
    return send(res, 200, { user: publicUser(other), messages: msgs.slice(-200) });
  }

  m = p.match(/^\/api\/read\/([a-z0-9_]+)$/);
  if (m && method === 'POST') {
    const other = m[1];
    const last = db.messages.reduce((a, x) => (x.from === other && x.to === me ? Math.max(a, x.id) : a), 0);
    db.reads[me] = db.reads[me] || {};
    db.reads[me][other] = last;
    save();
    return send(res, 200, { ok: true });
  }

  if (p === '/api/messages' && method === 'POST') {
    const b = await readBody(req);
    const to = normName(b.to);
    if (!db.users[to]) return send(res, 404, { error: 'Нет такого пользователя' });
    if (to === me) return send(res, 400, { error: 'Самому себе писать нельзя' });
    const text = String(b.text || '').toUpperCase();
    const photo = b.photo || null;
    if (text && (!ALLOWED.test(text) || text.length > MAX_TEXT)) {
      return send(res, 400, { error: 'Можно только буквы Т, Ы, Ф, Ь' });
    }
    if (photo && !PHOTOS.includes(photo)) return send(res, 400, { error: 'Нет такой фотографии' });
    if (!text && !photo) return send(res, 400, { error: 'Пустое сообщение' });
    const msg = { id: db.nextId++, from: me, to, text, photo, ts: Date.now() };
    db.messages.push(msg);
    save();
    push(me, { type: 'message', message: msg });
    push(to, { type: 'message', message: msg });
    return send(res, 200, msg);
  }

  return send(res, 404, { error: 'Не найдено' });
}

// ---------- статические файлы ----------
function serveStatic(req, res, url) {
  let rel = decodeURIComponent(url.pathname);
  if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(PUBLIC, rel));
  if (!file.startsWith(PUBLIC + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Не найдено'); }
    const ext = path.extname(file);
    const headers = { 'Content-Type': MIME[ext] || 'application/octet-stream' };
    headers['Cache-Control'] = (ext === '.jpg' || ext === '.png') ? 'public, max-age=604800' : 'no-cache';
    res.writeHead(200, headers);
    res.end(buf);
  });
}

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    if (url.pathname.startsWith('/api/')) await api(req, res, url);
    else serveStatic(req, res, url);
  } catch (e) {
    if (!res.headersSent) send(res, 400, { error: 'Плохой запрос' });
  }
}).listen(PORT, () => console.log(`Мурчат запущен: http://localhost:${PORT}`));
