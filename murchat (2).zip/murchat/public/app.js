(() => {
  'use strict';

  const PHOTOS = ['c1', 'c2', 'c3', 'c4'];
  const KEYS = ['Т', 'Ы', 'Ф', 'Ь'];
  const MAX = 300;
  const app = document.getElementById('app');

  let token = localStorage.getItem('mc_token') || '';
  let me = null;
  let chats = [];
  let es = null;
  let cur = null;          // открытый чат: { name, user, messages }
  let draft = '';
  let photo = null;
  let query = '';
  let found = [];
  let deferredPrompt = null;

  // ---------- мелочи ----------
  const asset = (p) => (window.MURCHAT_ASSETS && window.MURCHAT_ASSETS[p]) || p;
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const ICON = {
    back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/></svg>',
    send: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3.4 20.4l17.5-8a.5.5 0 000-.9L3.4 3.6a.5.5 0 00-.7.6L5 11l9 1-9 1-2.3 6.8a.5.5 0 00.7.6z"/></svg>',
    photo: '<svg viewBox="0 0 24 24" fill="currentColor"><ellipse cx="12" cy="16" rx="5" ry="4"/><circle cx="5.5" cy="11" r="2.2"/><circle cx="9.5" cy="6.8" r="2.2"/><circle cx="14.5" cy="6.8" r="2.2"/><circle cx="18.5" cy="11" r="2.2"/></svg>',
    del: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5h11a1 1 0 011 1v12a1 1 0 01-1 1H9l-6-7z"/><path d="M13 9.5l4.5 5M17.5 9.5l-4.5 5"/></svg>',
  };

  function hue(n) { let h = 0; for (const c of n) h = (h * 31 + c.charCodeAt(0)) % 360; return h; }

  function av(u, cls = '') {
    if (u.avatar) return `<img class="av ${cls}" src="${asset('/cats/' + u.avatar + '-t.jpg')}" alt="">`;
    const h = hue(u.username);
    return `<div class="av ph ${cls}" style="background:linear-gradient(135deg,hsl(${h} 90% 80%),hsl(${(h + 40) % 360} 90% 70%))">${esc(u.username[0].toUpperCase())}</div>`;
  }

  const fmtTime = (ts) => new Date(ts).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  function fmtDay(ts) {
    const d = new Date(ts), n = new Date();
    const same = (a, b) => a.toDateString() === b.toDateString();
    if (same(d, n)) return 'Сегодня';
    const y = new Date(n); y.setDate(n.getDate() - 1);
    if (same(d, y)) return 'Вчера';
    return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' });
  }

  let toastTimer;
  function toast(text) {
    const t = document.getElementById('toast');
    t.textContent = text;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
  }

  async function api(path, opts = {}) {
    let status, data = {};
    if (window.MURCHAT_LOCAL) {
      ({ status, data } = await window.MURCHAT_LOCAL(path, opts, token));
    } else {
      const headers = { 'Content-Type': 'application/json' };
      if (token) headers.Authorization = 'Bearer ' + token;
      const r = await fetch('/api' + path, {
        method: opts.method || 'GET', headers, body: opts.body ? JSON.stringify(opts.body) : undefined,
      });
      status = r.status;
      try { data = await r.json(); } catch (e) { /* пусто */ }
    }
    if (status === 401 && token) { logoutLocal(); throw new Error('Нужно войти заново'); }
    if (status < 200 || status >= 300) throw new Error(data.error || 'Что-то пошло не так');
    return data;
  }

  function logoutLocal() {
    token = ''; me = null; cur = null; chats = [];
    localStorage.removeItem('mc_token');
    if (es) { es.close(); es = null; }
    if (location.hash) history.replaceState(null, '', location.pathname + location.search);
    renderAuth();
  }

  // ---------- вход / регистрация ----------
  function renderAuth(mode = 'login') {
    cur = null;
    const reg = mode === 'register';
    app.innerHTML = `
      <div class="screen auth">
        <form class="card" id="authForm" autocomplete="on">
          <img class="logo" src="${asset('/icons/icon-192.png')}" alt="">
          <h1>Мурчат</h1>
          <p>${reg ? 'Придумай юзернейм и пароль' : 'Мессенджер для самых няшных'}</p>
          ${window.MURCHAT_LOCAL ? '<p class="tip" style="margin:-8px 0 12px">Демо: данные хранятся только в этом браузере. Попробуй написать котам @kisa, @pushok или @manul 🐾</p>' : ''}
          <input class="field" id="u" placeholder="юзернейм (латиницей)" autocapitalize="none" autocomplete="username" spellcheck="false" maxlength="20">
          <input class="field" id="p" type="password" placeholder="пароль" autocomplete="${reg ? 'new-password' : 'current-password'}" maxlength="64">
          <div class="err" id="err"></div>
          <button class="btn" type="submit">${reg ? 'Создать аккаунт' : 'Войти'}</button>
          <button class="link" type="button" id="sw">${reg ? 'Уже есть аккаунт? Войти' : 'Нет аккаунта? Регистрация'}</button>
        </form>
      </div>`;
    document.getElementById('sw').onclick = () => renderAuth(reg ? 'login' : 'register');
    document.getElementById('authForm').onsubmit = async (e) => {
      e.preventDefault();
      const err = document.getElementById('err');
      const btn = e.target.querySelector('.btn');
      err.textContent = ''; btn.disabled = true;
      try {
        const d = await api(reg ? '/register' : '/login', {
          method: 'POST', body: { username: document.getElementById('u').value, password: document.getElementById('p').value },
        });
        token = d.token; me = d.me;
        localStorage.setItem('mc_token', token);
        connect(); route();
      } catch (ex) { err.textContent = ex.message; btn.disabled = false; }
    };
  }

  // ---------- главный экран ----------
  function renderMain() {
    cur = null; draft = ''; photo = null; query = ''; found = [];
    app.innerHTML = `
      <div class="screen">
        <div class="top">
          <div class="top-row">
            <button class="avatar-btn" id="meBtn" aria-label="Профиль">${av(me, 'sm')}</button>
            <h1>Мурчат</h1>
          </div>
          <label class="search">${ICON.search}<input id="q" placeholder="Найти друга по юзернейму" autocapitalize="none" autocomplete="off" spellcheck="false"></label>
        </div>
        <div class="list" id="list"></div>
      </div>`;
    document.getElementById('meBtn').onclick = openProfile;
    let t;
    document.getElementById('q').oninput = (e) => {
      query = e.target.value.trim().replace(/^@/, '');
      clearTimeout(t);
      if (!query) { found = []; drawList(); return; }
      t = setTimeout(async () => {
        try {
          const r = await api('/users?q=' + encodeURIComponent(query));
          if (query) { found = r; drawList(); }
        } catch (ex) { /* ignore */ }
      }, 220);
    };
    drawList();
    loadChats();
  }

  async function loadChats() {
    try { chats = await api('/chats'); } catch (e) { return; }
    if (!cur && document.getElementById('list')) drawList();
  }

  function chatRow(name, user, pv, tm, unread) {
    return `<button class="chat" data-u="${esc(name)}">
      ${av(user)}
      <div class="mid"><div class="nm">@${esc(name)}</div><div class="pv">${pv}</div></div>
      <div class="meta"><span class="tm">${tm}</span>${unread ? `<span class="badge">${unread}</span>` : ''}</div>
    </button>`;
  }

  function drawList() {
    const list = document.getElementById('list');
    if (!list) return;
    let html = '';
    if (query) {
      html += '<div class="section-title">Найденные друзья</div>';
      if (!found.length) {
        html += `<div class="empty"><b>Никого не нашлось</b>Проверь юзернейм: пишем латиницей, без пробелов 🐾</div>`;
      } else {
        html += found.map((u) => `<button class="chat" data-u="${esc(u.username)}">${av(u)}
          <div class="mid"><div class="nm">@${esc(u.username)}</div><div class="pv"><i>Нажми, чтобы написать</i></div></div></button>`).join('');
      }
    } else if (!chats.length) {
      html = `<div class="empty"><img src="${asset('/icons/icon-192.png')}" alt=""><b>Пока тут пусто</b>Найди друга по юзернейму в поиске сверху и отправь ему «ТЫФЬ» 🐾</div>`;
    } else {
      html = chats.map((c) => {
        const l = c.last;
        const who = l.from === me.username ? '<i>Ты: </i>' : '';
        const pv = who + (l.photo ? '<i>🐱 </i>' : '') + esc(l.text);
        return chatRow(c.with, c.user, pv, fmtTime(l.ts), c.unread);
      }).join('');
    }
    list.innerHTML = html;
    list.querySelectorAll('.chat').forEach((b) => { b.onclick = () => { location.hash = '#/chat/' + b.dataset.u; }; });
  }

  // ---------- профиль ----------
  function sheet(html) {
    closeSheet();
    const w = document.createElement('div');
    w.className = 'sheet-wrap';
    w.innerHTML = `<div class="sheet"><div class="grab"></div>${html}</div>`;
    w.addEventListener('click', (e) => { if (e.target === w) closeSheet(); });
    document.body.appendChild(w);
    return w;
  }
  function closeSheet() { document.querySelectorAll('.sheet-wrap').forEach((n) => n.remove()); }

  function openProfile() {
    const w = sheet(`
      ${av(me, 'xl')}
      <div class="name">@${esc(me.username)}</div>
      <div class="sub">Выбери аватарку из котят</div>
      <div class="grid small">${PHOTOS.map((p) => `<button data-p="${p}" class="${me.avatar === p ? 'sel' : ''}"><img src="${asset('/cats/' + p + '-t.jpg')}" alt=""></button>`).join('')}</div>
      <div class="stack">
        ${me.avatar ? '<button class="btn ghost" id="noav">Убрать аватарку</button>' : ''}
        ${deferredPrompt ? '<button class="btn" id="inst">Установить приложение</button>' : ''}
        <button class="btn ghost" id="out">Выйти</button>
      </div>
      ${deferredPrompt ? '' : '<p class="tip">Чтобы Мурчат был на экране телефона: в меню браузера выбери «Установить приложение» или «Добавить на главный экран».</p>'}`);
    const setAv = async (a) => {
      try { me = await api('/me', { method: 'PUT', body: { avatar: a } }); } catch (e) { toast(e.message); return; }
      closeSheet();
      if (cur) updateChatHeader(); else renderMain();
      toast('Аватарка обновлена 🐾');
    };
    w.querySelectorAll('[data-p]').forEach((b) => { b.onclick = () => setAv(b.dataset.p); });
    const noav = w.querySelector('#noav'); if (noav) noav.onclick = () => setAv(null);
    const inst = w.querySelector('#inst');
    if (inst) inst.onclick = async () => { deferredPrompt.prompt(); await deferredPrompt.userChoice; deferredPrompt = null; closeSheet(); };
    w.querySelector('#out').onclick = async () => { closeSheet(); try { await api('/logout', { method: 'POST' }); } catch (e) { /* ignore */ } logoutLocal(); };
  }

  // ---------- чат ----------
  function renderChatShell(name) {
    app.innerHTML = `
      <div class="screen">
        <div class="top">
          <div class="top-row">
            <button class="icon-btn" id="back" aria-label="Назад">${ICON.back}</button>
            <span id="hAv"></span>
            <div class="who"><b>@${esc(name)}</b><small>мурчит где-то рядом</small></div>
            <button class="avatar-btn" id="meBtn" aria-label="Профиль">${av(me, 'sm')}</button>
          </div>
        </div>
        <div class="msgs" id="msgs"></div>
        <div class="composer">
          <div id="prev"></div>
          <div class="input-row">
            <button class="round photo" id="pickPhoto" aria-label="Фото котят">${ICON.photo}</button>
            <div class="draft" id="draft"></div>
            <button class="round send" id="send" aria-label="Отправить">${ICON.send}</button>
          </div>
          <div class="keys">
            ${KEYS.map((k, i) => `<button class="key k${i}" data-k="${k}">${k}</button>`).join('')}
            <button class="key del" id="del" aria-label="Стереть">${ICON.del}</button>
          </div>
          <div class="hint">писать можно только буквы Т · Ы · Ф · Ь</div>
        </div>
      </div>`;
    document.getElementById('back').onclick = () => { location.hash = ''; };
    document.getElementById('meBtn').onclick = openProfile;
    document.getElementById('pickPhoto').onclick = openPhotoPicker;
    document.getElementById('send').onclick = sendMsg;
    document.getElementById('del').onclick = () => { draft = draft.slice(0, -1); drawDraft(); };
    app.querySelectorAll('[data-k]').forEach((b) => { b.onclick = () => addLetter(b.dataset.k); });
    drawDraft(); drawPreview(); updateChatHeader();
  }

  function updateChatHeader() {
    const h = document.getElementById('hAv');
    if (h && cur) h.innerHTML = av(cur.user, 'sm');
    const m = document.getElementById('meBtn');
    if (m) m.innerHTML = av(me, 'sm');
  }

  function addLetter(l) { if (draft.length < MAX) { draft += l; drawDraft(); } }

  function drawDraft() {
    const d = document.getElementById('draft');
    if (!d) return;
    d.innerHTML = draft ? `${esc(draft)}<span class="caret"></span>` : '<span class="ph">Нажимай на буквы ниже…</span>';
    d.scrollTop = d.scrollHeight;
    document.getElementById('send').disabled = !draft && !photo;
  }

  function drawPreview() {
    const p = document.getElementById('prev');
    if (!p) return;
    p.innerHTML = photo ? `<div class="preview"><div class="pw"><img src="${asset('/cats/' + photo + '-t.jpg')}" alt=""><button class="x" id="rmPhoto" aria-label="Убрать фото">✕</button></div><span>Котик отправится с сообщением</span></div>` : '';
    const r = document.getElementById('rmPhoto');
    if (r) r.onclick = () => { photo = null; drawPreview(); drawDraft(); };
    const s = document.getElementById('send');
    if (s) s.disabled = !draft && !photo;
  }

  function openPhotoPicker() {
    const w = sheet(`
      <h2>Выбери котика</h2>
      <div class="sub">Можно отправить одно фото за раз</div>
      <div class="grid">${PHOTOS.map((p) => `<button data-p="${p}" class="${photo === p ? 'sel' : ''}"><img src="${asset('/cats/' + p + '.jpg')}" alt=""></button>`).join('')}</div>`);
    w.querySelectorAll('[data-p]').forEach((b) => {
      b.onclick = () => { photo = b.dataset.p; closeSheet(); drawPreview(); };
    });
  }

  function drawMessages(forceBottom) {
    const box = document.getElementById('msgs');
    if (!box || !cur) return;
    const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 140;
    let html = '', lastDay = '';
    if (!cur.messages.length) {
      html = `<div class="empty"><img src="${asset(cur.user.avatar ? '/cats/' + cur.user.avatar + '-t.jpg' : '/icons/icon-192.png')}" alt=""><b>Начни разговор</b>Скажи «ТЫФЬ» — друг поймёт 🐾</div>`;
    }
    for (const m of cur.messages) {
      const day = fmtDay(m.ts);
      if (day !== lastDay) { html += `<div class="day">${esc(day)}</div>`; lastDay = day; }
      const mine = m.from === me.username;
      html += `<div class="msg ${mine ? 'mine' : 'theirs'}"><div class="bubble">
        ${m.photo ? `<img class="mphoto" data-big="${esc(m.photo)}" src="${asset('/cats/' + m.photo + '.jpg')}" alt="">` : ''}
        ${m.text ? `<div class="mtext">${esc(m.text)}</div>` : ''}
        <span class="time">${fmtTime(m.ts)}</span></div></div>`;
    }
    box.innerHTML = html;
    box.querySelectorAll('.mphoto').forEach((i) => { i.onclick = () => openLightbox(i.dataset.big); });
    if (forceBottom || nearBottom) box.scrollTop = box.scrollHeight;
  }

  function openLightbox(p) {
    const l = document.createElement('div');
    l.className = 'lightbox';
    l.innerHTML = `<img src="${asset('/cats/' + p + '.jpg')}" alt="">`;
    l.onclick = () => l.remove();
    document.body.appendChild(l);
  }

  async function openChat(name) {
    cur = { name, user: { username: name, avatar: null }, messages: [] };
    draft = ''; photo = null;
    renderChatShell(name);
    try {
      const d = await api('/messages/' + name);
      if (!cur || cur.name !== name) return;
      cur.user = d.user; cur.messages = d.messages;
    } catch (e) { toast(e.message); location.hash = ''; return; }
    updateChatHeader();
    drawMessages(true);
    api('/read/' + name, { method: 'POST' }).then(loadChats).catch(() => {});
  }

  async function refreshChat() {
    if (!cur) return;
    const name = cur.name;
    try {
      const d = await api('/messages/' + name);
      if (cur && cur.name === name) { cur.messages = d.messages; drawMessages(); }
    } catch (e) { /* ignore */ }
  }

  async function sendMsg() {
    if (!cur || (!draft && !photo)) return;
    const body = { to: cur.name, text: draft, photo };
    draft = ''; photo = null; drawDraft(); drawPreview();
    try {
      const msg = await api('/messages', { method: 'POST', body });
      onMessage(msg, true);
    } catch (e) {
      toast(e.message);
      if (!draft && !photo) { draft = body.text; photo = body.photo; drawDraft(); drawPreview(); }
    }
  }

  function onMessage(msg, mine) {
    const other = msg.from === me.username ? msg.to : msg.from;
    if (cur && cur.name === other) {
      if (!cur.messages.some((m) => m.id === msg.id)) { cur.messages.push(msg); drawMessages(mine); }
      if (msg.to === me.username) api('/read/' + other, { method: 'POST' }).catch(() => {});
    } else if (msg.to === me.username) {
      toast(`@${msg.from}: ${msg.text || '🐱 котик'}`);
    }
    loadChats();
  }

  // ---------- физическая клавиатура ----------
  document.addEventListener('keydown', (e) => {
    if (!cur || e.ctrlKey || e.metaKey || e.altKey) return;
    if (document.querySelector('.sheet-wrap')) return;
    const k = e.key.length === 1 ? e.key.toUpperCase() : e.key;
    if (KEYS.includes(k)) { e.preventDefault(); addLetter(k); }
    else if (k === 'Backspace') { e.preventDefault(); draft = draft.slice(0, -1); drawDraft(); }
    else if (k === 'Enter') { e.preventDefault(); sendMsg(); }
    else if (e.key.length === 1) e.preventDefault();
  });

  // ---------- реальное время ----------
  function connect() {
    if (window.MURCHAT_LOCAL_SUBSCRIBE) { window.MURCHAT_LOCAL_SUBSCRIBE(me.username, (msg) => onMessage(msg, false)); loadChats(); return; }
    if (es) es.close();
    es = new EventSource('/api/events?token=' + encodeURIComponent(token));
    es.onmessage = (e) => {
      try { const d = JSON.parse(e.data); if (d.type === 'message') onMessage(d.message, false); } catch (x) { /* ignore */ }
    };
    es.onopen = () => { loadChats(); refreshChat(); };
  }

  // ---------- маршрутизация ----------
  function route() {
    closeSheet();
    if (!token || !me) return renderAuth();
    const m = location.hash.match(/^#\/chat\/([a-z0-9_]+)$/);
    if (m) openChat(m[1]); else renderMain();
  }
  window.addEventListener('hashchange', route);

  window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferredPrompt = e; });

  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});

  // ---------- старт ----------
  (async () => {
    if (!token) return renderAuth();
    try { me = await api('/me'); connect(); route(); } catch (e) { if (!me) renderAuth(); }
  })();
})();
