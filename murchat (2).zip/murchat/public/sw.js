// Сервис-воркер: приложение открывается даже при плохой связи.
const CACHE = 'murchat-v1';
const SHELL = ['/', '/style.css', '/app.js', '/manifest.webmanifest',
  '/icons/icon-192.png', '/cats/c1-t.jpg', '/cats/c2-t.jpg', '/cats/c3-t.jpg', '/cats/c4-t.jpg'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) =>
    Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/')) return;
  // сначала сеть, при ошибке — кэш
  e.respondWith(
    fetch(e.request).then((res) => {
      const copy = res.clone();
      caches.open(CACHE).then((c) => c.put(e.request, copy));
      return res;
    }).catch(() => caches.match(e.request).then((r) => r || caches.match('/')))
  );
});
