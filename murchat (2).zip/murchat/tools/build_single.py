#!/usr/bin/env python3
"""Собирает один файл murchat.html (всё внутри: стили, скрипты, фото, иконка).
Запуск: python3 tools/build_single.py [куда сохранить]"""
import base64, io, os, sys
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PUB = os.path.join(ROOT, 'public')
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, 'murchat.html')

def read(p):
    with open(p, encoding='utf-8') as f:
        return f.read()

def data_uri(path, max_side=None, quality=80):
    im = Image.open(path)
    if max_side:
        im.thumbnail((max_side, max_side), Image.LANCZOS)
    buf = io.BytesIO()
    if path.endswith('.png'):
        im.save(buf, 'PNG', optimize=True); mime = 'image/png'
    else:
        im.convert('RGB').save(buf, 'JPEG', quality=quality, optimize=True, progressive=True); mime = 'image/jpeg'
    return f'data:{mime};base64,' + base64.b64encode(buf.getvalue()).decode()

assets = {}
for c in ['c1', 'c2', 'c3', 'c4']:
    assets[f'/cats/{c}.jpg'] = data_uri(os.path.join(PUB, 'cats', f'{c}.jpg'), 720, 78)
    assets[f'/cats/{c}-t.jpg'] = data_uri(os.path.join(PUB, 'cats', f'{c}-t.jpg'))
assets['/icons/icon-192.png'] = data_uri(os.path.join(PUB, 'icons', 'icon-192.png'))
favicon = data_uri(os.path.join(PUB, 'icons', 'favicon.png'))

import json
html = f'''<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, user-scalable=no">
<title>Мурчат</title>
<meta name="theme-color" content="#ff8fb1">
<link rel="icon" type="image/png" href="{favicon}">
<style>
{read(os.path.join(PUB, 'style.css'))}
</style>
</head>
<body>
<div id="app"></div>
<div id="toast" class="toast"></div>
<script>window.MURCHAT_ASSETS = {json.dumps(assets)};</script>
<script>
{read(os.path.join(ROOT, 'tools', 'local-api.js'))}
</script>
<script>
{read(os.path.join(PUB, 'app.js'))}
</script>
</body>
</html>
'''
with open(OUT, 'w', encoding='utf-8') as f:
    f.write(html)
print(OUT, round(os.path.getsize(OUT) / 1024), 'KB')
