// Мурчат: «сервер внутри браузера» для одиночного HTML-файла.
// Все данные лежат в localStorage этого браузера. Вкладки видят друг друга.
(() => {
  'use strict';
  const KEY = 'murchat_local_db_v1';
  const PHOTOS = ['c1', 'c2', 'c3', 'c4'];
  const ALLOWED = /^[ТЫФЬ]+$/;
  const NAME_RE = /^[a-z0-9_]{3,20}$/;
  const BOT_WORDS = ['ТЫФЬ', 'ФЫТЬ', 'ТЫТЫ', 'ФЬ', 'ЫФ', 'ТЫФЬТЫФЬ', 'ЬЫТ', 'ФФФ', 'ТЫ', 'ЫЫЫФЬ'];

  const bc = 'BroadcastChannel' in window ? new BroadcastChannel('murchat_local') : null;
  const listeners = [];

  function load() { try { return JSON.parse(localStorage.getItem(KEY)); } catch (e) { return null; } }
  function seed() {
    return {
      users: {
        kisa: { bot: true, avatar: 'c1' },
        pushok: { bot: true, avatar: 'c4' },
        manul: { bot: true, avatar: 'c3' },
      },
      sessions: {}, messages: [], reads: {}, nextId: 1,
    };
  }
  let db = load() || seed();
  const sync = () => { db = load() || db; };
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(db)); } catch (e) { /* ignore */ } };

  const hash = (s) => { let a = 5381; for (const c of s) a = ((a << 5) + a + c.charCodeAt(0)) | 0; return String(a >>> 0); };
  const norm = (s) => String(s || '').trim().replace(/^@/, '').toLowerCase();
  const pub = (n) => ({ username: n, avatar: db.users[n] ? db.users[n].avatar : null });
  const rand = (n) => Math.floor(Math.random() * n);
  const newToken = () => Array.from(crypto.getRandomValues(new Uint8Array(16))).map((b) => b.toString(16).padStart(2, '0')).join('');

  function dispatch(msg) {
    for (const l of listeners) if (l.name === msg.to || l.name === msg.from) l.cb(msg);
  }
  if (bc) bc.onmessage = (e) => { sync(); dispatch(e.data); };

  window.MURCHAT_LOCAL_SUBSCRIBE = (name, cb) => {
    for (let i = listeners.length - 1; i >= 0; i--) listeners.splice(i, 1);
    listeners.push({ name, cb });
  };

  function addMessage(from, to, text, photo) {
    sync();
    const msg = { id: db.nextId++, from, to, text, photo, ts: Date.now() };
    db.messages.push(msg);
    save();
    dispatch(msg);
    if (bc) bc.postMessage(msg);
    return msg;
  }

  function botReply(bot, to) {
    setTimeout(() => {
      sync();
      const text = BOT_WORDS[rand(BOT_WORDS.length)];
      const photo = Math.random() < 0.3 ? PHOTOS[rand(PHOTOS.length)] : null;
      addMessage(bot, to, text, photo);
    }, 900 + rand(900));
  }

  const ok = (data) => ({ status: 200, data });
  const err = (status, error) => ({ status, data: { error } });

  window.MURCHAT_LOCAL = async (rawPath, opts, token) => {
    sync();
    const method = opts.method || 'GET';
    const b = opts.body || {};
    const u = new URL('http://x' + rawPath);
    const p = u.pathname;

    if (p === '/register' && method === 'POST') {
      const name = norm(b.username), pass = String(b.password || '');
      if (!NAME_RE.test(name)) return err(400, 'Юзернейм: 3–20 символов, латиница, цифры и _');
      if (pass.length < 4) return err(400, 'Пароль: от 4 символов');
      if (db.users[name]) return err(409, 'Такой юзернейм уже занят');
      db.users[name] = { hash: hash(pass), avatar: null };
      const t = newToken(); db.sessions[t] = name; save();
      return ok({ token: t, me: pub(name) });
    }
    if (p === '/login' && method === 'POST') {
      const name = norm(b.username), usr = db.users[name];
      if (!usr || usr.bot || usr.hash !== hash(String(b.password || ''))) return err(401, 'Неверный юзернейм или пароль');
      const t = newToken(); db.sessions[t] = name; save();
      return ok({ token: t, me: pub(name) });
    }

    const me = db.sessions[token];
    if (!me || !db.users[me]) return err(401, 'Нужно войти');

    if (p === '/me' && method === 'GET') return ok(pub(me));
    if (p === '/me' && method === 'PUT') {
      if (b.avatar !== null && !PHOTOS.includes(b.avatar)) return err(400, 'Нет такой фотографии');
      db.users[me].avatar = b.avatar; save();
      return ok(pub(me));
    }
    if (p === '/logout' && method === 'POST') { delete db.sessions[token]; save(); return ok({ ok: true }); }

    if (p === '/users' && method === 'GET') {
      const q = norm(u.searchParams.get('q'));
      if (!q) return ok([]);
      return ok(Object.keys(db.users).filter((n) => n !== me && n.includes(q))
        .sort((a, c) => (c.startsWith(q) - a.startsWith(q)) || a.localeCompare(c)).slice(0, 20).map(pub));
    }

    if (p === '/chats' && method === 'GET') {
      const map = new Map();
      for (const m of db.messages) {
        if (m.from !== me && m.to !== me) continue;
        const other = m.from === me ? m.to : m.from;
        const c = map.get(other) || { with: other, unread: 0, last: null };
        c.last = m;
        if (m.to === me && m.id > ((db.reads[me] || {})[other] || 0)) c.unread++;
        map.set(other, c);
      }
      return ok([...map.values()].sort((a, c) => c.last.id - a.last.id).map((c) => ({ ...c, user: pub(c.with) })));
    }

    let m = p.match(/^\/messages\/([a-z0-9_]+)$/);
    if (m && method === 'GET') {
      const other = m[1];
      if (!db.users[other]) return err(404, 'Нет такого пользователя');
      const msgs = db.messages.filter((x) => (x.from === me && x.to === other) || (x.from === other && x.to === me));
      return ok({ user: pub(other), messages: msgs.slice(-200) });
    }

    m = p.match(/^\/read\/([a-z0-9_]+)$/);
    if (m && method === 'POST') {
      const other = m[1];
      const last = db.messages.reduce((a, x) => (x.from === other && x.to === me ? Math.max(a, x.id) : a), 0);
      db.reads[me] = db.reads[me] || {}; db.reads[me][other] = last; save();
      return ok({ ok: true });
    }

    if (p === '/messages' && method === 'POST') {
      const to = norm(b.to);
      if (!db.users[to]) return err(404, 'Нет такого пользователя');
      if (to === me) return err(400, 'Самому себе писать нельзя');
      const text = String(b.text || '').toUpperCase();
      const photo = b.photo || null;
      if (text && (!ALLOWED.test(text) || text.length > 300)) return err(400, 'Можно только буквы Т, Ы, Ф, Ь');
      if (photo && !PHOTOS.includes(photo)) return err(400, 'Нет такой фотографии');
      if (!text && !photo) return err(400, 'Пустое сообщение');
      const msg = addMessage(me, to, text, photo);
      if (db.users[to].bot) botReply(to, me);
      return ok(msg);
    }
    return err(404, 'Не найдено');
  };
})();
